package com.teamthree.legalaid.service;

import com.teamthree.legalaid.dto.CaseDTO;
import com.teamthree.legalaid.dto.CreateCaseRequest;
import com.teamthree.legalaid.entity.Case;
import com.teamthree.legalaid.entity.User;
import com.teamthree.legalaid.repository.CaseRepository;
import com.teamthree.legalaid.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class CaseService {

    private final CaseRepository caseRepository;
    private final UserRepository userRepository;

    @Transactional
    public CaseDTO createCase(User user, CreateCaseRequest request) {
        Case newCase = new Case();
        newCase.setUserId(user.getId());
        
        // Set fields
        newCase.setCaseTitle(request.getCaseTitle());
        newCase.setTitle(request.getCaseTitle());
        newCase.setCaseDescription(request.getDescription());
        newCase.setDescription(request.getDescription());
        newCase.setCategory(request.getCategory());
        newCase.setLocation(request.getLocation());
        newCase.setStatus("SUBMITTED");
        newCase.setFiledDate(LocalDateTime.now());
        
        Case savedCase = caseRepository.save(newCase);
        return mapToDTO(savedCase, user);
    }

    public List<CaseDTO> getUserCases(User user) {
        // Fix: Use correct method name - assuming you need a custom query for this
        return caseRepository.findByClientOrderByFiledDateDesc(user)
                .stream()
                .map(c -> mapToDTO(c, user))
                .collect(Collectors.toList());
    }

    public CaseDTO getCaseById(Long id) {
        Case case_ = caseRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Case not found with id: " + id));
        
        User user = null;
        if (case_.getClient() != null) {
            user = case_.getClient();
        } else if (case_.getUserId() != null) {
            user = userRepository.findById(case_.getUserId()).orElse(null);
        }
        
        return mapToDTO(case_, user);
    }

    public List<CaseDTO> filterCases(Long userId, String status, String category) {
        // Fix: You need to implement this method in CaseRepository
        // For now, let's use a basic approach
        List<Case> cases = caseRepository.findAll();
        return cases.stream()
                .filter(c -> userId == null || (c.getUserId() != null && c.getUserId().equals(userId)))
                .filter(c -> status == null || status.equals(c.getStatus()))
                .filter(c -> category == null || category.equals(c.getCategory()))
                .map(c -> {
                    User user = c.getClient() != null ? c.getClient() : 
                               (c.getUserId() != null ? userRepository.findById(c.getUserId()).orElse(null) : null);
                    return mapToDTO(c, user);
                })
                .collect(Collectors.toList());
    }

    public boolean isCaseOwner(User user, Long caseId) {
        return caseRepository.findById(caseId)
                .map(c -> c.getClient() != null ? c.getClient().getId().equals(user.getId()) :
                         (c.getUserId() != null && c.getUserId().equals(user.getId())))
                .orElse(false);
    }

    private CaseDTO mapToDTO(Case case_, User user) {
        CaseDTO dto = new CaseDTO();
        dto.setId(case_.getId());
        dto.setUserId(case_.getUserId() != null ? case_.getUserId() : 
                      (case_.getClient() != null ? case_.getClient().getId() : null));
        
        // Use caseTitle for the DTO title field
        dto.setTitle(case_.getCaseTitle() != null ? case_.getCaseTitle() : case_.getTitle());
        
        dto.setDescription(case_.getCaseDescription() != null ? case_.getCaseDescription() : case_.getDescription());
        dto.setCategory(case_.getCategory());
        dto.setLocation(case_.getLocation());
        dto.setStatus(case_.getStatus());
        dto.setCreatedAt(case_.getCreatedAt());
        dto.setUpdatedAt(case_.getUpdatedAt());
        dto.setFilingDate(case_.getFiledDate());
        dto.setHearingDate(case_.getHearingDate());
        
        if (user != null) {
            dto.setUserName(user.getFullname());
            dto.setUserEmail(user.getEmail());
        } else if (case_.getClient() != null) {
            dto.setUserName(case_.getClient().getFullname());
            dto.setUserEmail(case_.getClient().getEmail());
        }
        
        return dto;
    }
}