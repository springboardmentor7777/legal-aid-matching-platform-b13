import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";

const Sidebar = () => {

  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  return (
    <div className="w-64 h-screen bg-white shadow-lg p-6 flex flex-col">

      <h2 className="text-2xl font-bold text-blue-600 mb-10">
        LegalAid
      </h2>

      <nav className="flex flex-col gap-4 flex-grow">

        {user?.role === "USER" && (
          <>
            <Link to="/dashboard">Dashboard</Link>
            <Link to="/submit-case">Submit Case</Link>
            <Link to="/my-cases">My Requests</Link>
            <Link to="/profile">Profile</Link>
          </>
        )}

      </nav>

      <button
        onClick={handleLogout}
        className="text-red-500 mt-auto"
      >
        Logout
      </button>

    </div>
  );
};

export default Sidebar;