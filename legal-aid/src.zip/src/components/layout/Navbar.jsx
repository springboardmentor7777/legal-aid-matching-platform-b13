import { Link } from "react-router-dom";

const Navbar = () => {
  return (
    <header className="w-full border-b bg-white">

      <div className="max-w-7xl mx-auto px-8 py-4 flex items-center justify-between">

        {/* Logo */}
        <Link
          to="/"
          className="text-xl font-semibold text-gray-800"
        >
          ⚖️ LegalAid
        </Link>

        {/* Right Buttons */}
        <div className="flex items-center gap-4">

          <Link
            to="/login"
            className="text-gray-700 hover:text-blue-600"
          >
            Sign In
          </Link>

          <Link
            to="/register"
            className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
          >
            Get Started
          </Link>

        </div>

      </div>

    </header>
  );
};

export default Navbar;