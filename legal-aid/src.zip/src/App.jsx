import { BrowserRouter, Routes, Route } from "react-router-dom";
import { Toaster } from "react-hot-toast";

import Home from "./pages/Home";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Dashboard from "./pages/Dashboard";
import Admin from "./pages/Admin";

import Users from "./pages/admin/Users";
import Lawyers from "./pages/admin/Lawyers";
import Ngos from "./pages/admin/Ngos";

import ProtectedRoute from "./components/common/ProtectedRoute";
import RoleBasedDashboard from "./components/common/RoleBasedDashboard";
import SubmitCase from "./pages/user/SubmitCase";
import MyCases from "./pages/user/MyCases";
import Profile from "./pages/user/Profile";
function App() {
  return (
    <BrowserRouter>
      <Toaster position="top-right" />

      <Routes>

        {/* Public Routes */}
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />

        {/* Role Based Dashboard */}
        <Route
          path="/dashboard"
          element={
            <ProtectedRoute>
              <RoleBasedDashboard />
            </ProtectedRoute>
          }
        />  

        <Route
  path="/profile"
  element={
    <ProtectedRoute>
      <Profile />
    </ProtectedRoute>
  }
 />

 <Route
  path="/dashboard"
  element={
    <ProtectedRoute>
      <RoleBasedDashboard />
    </ProtectedRoute>
  }
/>

        <Route
  path="/my-cases"
  element={
    <ProtectedRoute>
      <MyCases />
    </ProtectedRoute>
  }
 />

        {/* Admin Dashboard */}
        <Route
          path="/admin"
          element={
            <ProtectedRoute role="ADMIN">
              <Admin />
            </ProtectedRoute>
          }
        />

        {/* Admin Management Pages */}
        <Route
          path="/admin/users"
          element={
            <ProtectedRoute role="ADMIN">
              <Users />
            </ProtectedRoute>
          }
        />

        <Route
          path="/admin/lawyers"
          element={
            <ProtectedRoute role="ADMIN">
              <Lawyers />
            </ProtectedRoute>
          }
        />
        <Route
  path="/submit-case"
  element={
    <ProtectedRoute>
      <SubmitCase />
    </ProtectedRoute>
  }
 />

        <Route
          path="/admin/ngos"
          element={
            <ProtectedRoute role="ADMIN">
              <Ngos />
            </ProtectedRoute>
          }
        />

      </Routes>
    </BrowserRouter>
  );
}

export default App;