import Layout from "../../components/layout/Layout";

function NgoDashboard() {
  return (
    <Layout>
      <h1 className="text-2xl font-bold">NGO Dashboard 🤝</h1>
    </Layout>
  );
}

export default NgoDashboard;