import { useEffect, useState } from "react";
import Layout from "../../components/layout/Layout";
import API from "../../api/axios";

const UserDashboard = () => {

  const [cases, setCases] = useState([]);

  useEffect(() => {

    const fetchCases = async () => {

      try {

        const res = await API.get("/api/cases");
        setCases(res.data);

      } catch (err) {

        console.error("Failed to load cases", err);

      }

    };

    fetchCases();

  }, []);

  return (
    <Layout>

      <h1 className="text-2xl font-bold mb-6">
        User Dashboard 👤
      </h1>

      <p className="mb-6 text-gray-600">
        View your cases and legal requests.
      </p>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-6 mb-8">

        <div className="bg-white p-6 rounded-xl shadow">
          <h3 className="text-gray-500">Total Cases</h3>
          <p className="text-2xl font-bold">{cases.length}</p>
        </div>

        <div className="bg-white p-6 rounded-xl shadow">
          <h3 className="text-gray-500">Pending</h3>
          <p className="text-2xl font-bold">
            {cases.filter(c => c.status === "PENDING").length}
          </p>
        </div>

        <div className="bg-white p-6 rounded-xl shadow">
          <h3 className="text-gray-500">Resolved</h3>
          <p className="text-2xl font-bold">
            {cases.filter(c => c.status === "RESOLVED").length}
          </p>
        </div>

      </div>

      {/* Recent Cases */}

      <div className="bg-white p-6 rounded-xl shadow">

        <h2 className="text-lg font-semibold mb-4">
          Recent Cases
        </h2>

        {cases.length === 0 ? (
          <p>No cases submitted yet.</p>
        ) : (
          cases.slice(0,3).map(c => (
            <div key={c.id} className="border-b py-2">

              <p className="font-semibold">{c.title}</p>
              <p className="text-sm text-gray-500">
                Status: {c.status || "Pending"}
              </p>

            </div>
          ))
        )}

      </div>

    </Layout>
  );
};

export default UserDashboard;