import Layout from "../../components/layout/Layout";

const LawyerDashboard = () => {
  return (
    <Layout>
      <h1 className="text-2xl font-bold">Lawyer Dashboard ⚖️</h1>
    </Layout>
  );
};

export default LawyerDashboard;