import { useState } from "react";
import { Link } from "react-router-dom";
import API from "../api/axios";

const Register = () => {

  const [form, setForm] = useState({
    fullName:"",
    email:"",
    password:"",
    role:"USER"
  });

  const handleChange = (e)=>{
    setForm({...form,[e.target.name]:e.target.value});
  };

  const handleSubmit = async (e)=>{
    e.preventDefault();
    await API.post("/auth/register",form);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">

      <div className="bg-white p-10 rounded-xl shadow w-full max-w-md">

        <h1 className="text-2xl font-bold text-center mb-2">
          Create account
        </h1>

        <p className="text-gray-500 text-center mb-6">
          Join the Legal Aid platform
        </p>

        <form onSubmit={handleSubmit} className="space-y-4">

          <input
            name="fullName"
            placeholder="Full Name"
            className="w-full border p-3 rounded"
            onChange={handleChange}
          />

          <input
            name="email"
            placeholder="Email"
            className="w-full border p-3 rounded"
            onChange={handleChange}
          />

          <input
            type="password"
            name="password"
            placeholder="Password"
            className="w-full border p-3 rounded"
            onChange={handleChange}
          />

          <select
            name="role"
            className="w-full border p-3 rounded"
            onChange={handleChange}
          >
            <option value="USER">User — Need legal help</option>
            <option value="LAWYER">Lawyer</option>
            <option value="NGO">NGO</option>
          </select>

          <button className="w-full bg-blue-600 text-white py-3 rounded hover:bg-blue-700">
            Create Account
          </button>

        </form>

        <p className="text-center mt-6 text-sm">
          Already have an account?{" "}
          <Link to="/login" className="text-blue-600">
            Sign in
          </Link>
        </p>

      </div>

    </div>
  );
};

export default Register;