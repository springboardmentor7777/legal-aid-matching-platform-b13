import Layout from "../../components/layout/Layout";

const Ngos = () => {
  return (
    <Layout>
      <h1 className="text-2xl font-bold mb-6">NGO Management 🤝</h1>
    </Layout>
  );
};

export default Ngos;