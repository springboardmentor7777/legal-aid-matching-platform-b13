import Layout from "../../components/layout/Layout";

const Lawyers = () => {
  return (
    <Layout>
      <h1 className="text-2xl font-bold">Lawyers Management ⚖️</h1>

      <div className="bg-white p-6 rounded-xl shadow mt-6">
        Lawyers list will appear here.
      </div>
    </Layout>
  );
};

export default Lawyers;