import Layout from "../../components/layout/Layout";

const Users = () => {
  return (
    <Layout>
      <h1 className="text-2xl font-bold mb-6">Users Management 👥</h1>

      <div className="bg-white p-6 rounded-xl shadow">
        Users list will appear here.
      </div>
    </Layout>
  );
};

export default Users;