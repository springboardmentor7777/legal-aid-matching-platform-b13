import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import API from "../api/axios";

const Login = () => {

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const navigate = useNavigate();

  const handleSubmit = async (e) => {
  e.preventDefault();

  try {

    const res = await API.post("/auth/login", {
      email,
      password
    });

    // store token
    localStorage.setItem("token", res.data.token);

    // redirect
    navigate("/dashboard");

  } catch (error) {

    console.error(error);
    alert("Login failed");

  }
 };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">

      <div className="bg-white p-10 rounded-xl shadow w-full max-w-md">

        <h1 className="text-2xl font-bold text-center mb-2">
          Welcome back
        </h1>

        <p className="text-gray-500 text-center mb-6">
          Sign in to your account
        </p>

        <form onSubmit={handleSubmit} className="space-y-4">

          <input
            type="email"
            placeholder="Email"
            className="w-full border p-3 rounded"
            value={email}
            onChange={(e)=>setEmail(e.target.value)}
          />

          <input
            type="password"
            placeholder="Password"
            className="w-full border p-3 rounded"
            value={password}
            onChange={(e)=>setPassword(e.target.value)}
          />

          <button className="w-full bg-blue-600 text-white py-3 rounded hover:bg-blue-700">
            Sign In
          </button>

        </form>

        <p className="text-center mt-6 text-sm">
          Don't have an account?{" "}
          <Link to="/register" className="text-blue-600">
            Sign up
          </Link>
        </p>

      </div>

    </div>
  );
};

export default Login;