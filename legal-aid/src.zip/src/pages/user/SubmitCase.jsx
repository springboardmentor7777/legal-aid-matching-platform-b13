import { useState } from "react";
import Layout from "../../components/layout/Layout";
import API from "../../api/axios";
import toast from "react-hot-toast";

const SubmitCase = () => {

  const [form, setForm] = useState({
    title: "",
    description: "",
    category: "",
    urgency: "LOW",
    location: ""
  });

  const handleChange = (e) => {

    setForm({
      ...form,
      [e.target.name]: e.target.value
    });

  };

  const handleSubmit = async (e) => {

    e.preventDefault();

    try {

      await API.post("/api/cases", form);

      toast.success("Case submitted successfully");

      setForm({
        title: "",
        description: "",
        category: "",
        urgency: "LOW",
        location: ""
      });

    } catch (error) {

      toast.error("Failed to submit case");

    }

  };

  return (
  <Layout>

    <div className="flex justify-center items-center min-h-[80vh]">

      <div className="w-full max-w-xl bg-white p-8 rounded-xl shadow">

        <h1 className="text-2xl font-bold mb-6 text-center">
          Submit Legal Case
        </h1>

        <form onSubmit={handleSubmit} className="space-y-4">

          <input
            name="title"
            placeholder="Case Title"
            value={form.title}
            onChange={handleChange}
            className="w-full border p-3 rounded"
            required
          />

          <textarea
            name="description"
            placeholder="Describe your issue"
            value={form.description}
            onChange={handleChange}
            className="w-full border p-3 rounded"
            rows="4"
            required
          />

          <input
            name="category"
            placeholder="Category (Property, Criminal, Family...)"
            value={form.category}
            onChange={handleChange}
            className="w-full border p-3 rounded"
          />

          <select
            name="urgency"
            value={form.urgency}
            onChange={handleChange}
            className="w-full border p-3 rounded"
          >
            <option value="LOW">Low</option>
            <option value="MEDIUM">Medium</option>
            <option value="HIGH">High</option>
          </select>

          <input
            name="location"
            placeholder="Location"
            value={form.location}
            onChange={handleChange}
            className="w-full border p-3 rounded"
          />

          <button
            type="submit"
            className="w-full bg-blue-600 text-white py-3 rounded hover:bg-blue-700"
          >
            Submit Case
          </button>

        </form>

      </div>

    </div>

  </Layout>
);
};

export default SubmitCase;