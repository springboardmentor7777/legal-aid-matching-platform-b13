import { useEffect, useState } from "react";
import Layout from "../../components/layout/Layout";
import API from "../../api/axios";

const MyCases = () => {

  const [cases, setCases] = useState([]);

  useEffect(() => {

    const fetchCases = async () => {

      try {

        const res = await API.get("/api/cases");
        setCases(res.data);

      } catch (error) {

        console.error("Error fetching cases", error);

      }

    };

    fetchCases();

  }, []);

  return (
    <Layout>

      <h1 className="text-2xl font-bold mb-6">
        My Cases
      </h1>

      {cases.length === 0 && (
        <p>No cases found.</p>
      )}

      {cases.map((c) => (
        <div key={c.id} className="bg-white p-4 mb-4 rounded shadow">

          <h2 className="font-semibold">
            {c.title}
          </h2>

          <p className="text-gray-600">
            {c.description}
          </p>

          <p className="text-sm mt-2">
            Status: {c.status || "Pending"}
          </p>

        </div>
      ))}

    </Layout>
  );
};

export default MyCases;