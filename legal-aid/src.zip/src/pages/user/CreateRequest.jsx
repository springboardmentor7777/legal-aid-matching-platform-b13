import { useState } from "react";
import Layout from "../../components/layout/Layout";
import API from "../../api/axios";
import toast from "react-hot-toast";

const CreateRequest = () => {
  const [form, setForm] = useState({
    title: "",
    description: "",
    category: ""
  });

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      await API.post("/user/requests", form);
      toast.success("Request submitted successfully");
    } catch (err) {
      toast.error("Failed to submit request");
    }
  };

  return (
    <Layout>
      <h1 className="text-2xl font-bold mb-6">Submit Legal Request</h1>

      <form
        onSubmit={handleSubmit}
        className="bg-white p-6 rounded-xl shadow-md space-y-4 max-w-lg"
      >
        <input
          type="text"
          placeholder="Title"
          className="w-full border p-3 rounded-lg"
          onChange={(e) =>
            setForm({ ...form, title: e.target.value })
          }
        />

        <textarea
          placeholder="Describe your issue"
          className="w-full border p-3 rounded-lg"
          onChange={(e) =>
            setForm({ ...form, description: e.target.value })
          }
        />

        <input
          type="text"
          placeholder="Category"
          className="w-full border p-3 rounded-lg"
          onChange={(e) =>
            setForm({ ...form, category: e.target.value })
          }
        />

        <button className="bg-blue-500 text-white px-4 py-2 rounded-lg">
          Submit Request
        </button>
      </form>
    </Layout>
  );
};

export default CreateRequest;